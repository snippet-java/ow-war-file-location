const fs        = require('fs');

let html        = fs.readFileSync(__dirname+'/playground.html','utf8');

function main(params) {
        console.log("hello-2");
        return {html: html}
}

exports.main = main;