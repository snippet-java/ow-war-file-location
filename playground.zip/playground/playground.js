const fs        = require('fs');

let html        = fs.readFileSync(__dirname+'/playground.html','utf8');

function main(params) {
        return {html: html}
}

exports.main = main;