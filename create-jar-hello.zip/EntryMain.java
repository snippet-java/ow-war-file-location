import com.google.gson.JsonObject;
public class EntryMain {
	public static JsonObject main(JsonObject args) {	
		JsonObject response = new JsonObject();
		response.addProperty("response", "Hello World");
		return response; 
	}
}
