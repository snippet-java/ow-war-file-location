import com.google.gson.JsonObject;

public class EntryMain {

	public static JsonObject main(JsonObject args) {
		   
		EntryMain owConn = new EntryMain();
		
		String rawInputValue = args.getAsJsonObject("request").getAsJsonObject("intent")
				.getAsJsonObject("slots").getAsJsonObject("Text").getAsJsonPrimitive("value").getAsString().toLowerCase();
		
		JsonObject session = args.getAsJsonObject("session");
		
		if(rawInputValue.contains("set survey") || rawInputValue.contains("use survey"))
        	return owConn.set(session, rawInputValue);
        else if(rawInputValue.contains("start") && rawInputValue.contains("survey"))
        	return owConn.start(session, rawInputValue);
        else 
        	return owConn.reply(session, rawInputValue);
	    }

	private JsonObject set(JsonObject session, String userInput) {
        
        String sessionId = session.getAsJsonPrimitive("sessionId").getAsString();
        JsonObject output = new Use().setbook(sessionId, userInput);
        
        String speechText = "", repromptText = "";

        speechText = output.get("message").getAsString();
        if(output.has("reprompt"))
        	repromptText = output.get("message").getAsString();
        
        JsonObject response = constructResponseObject(speechText, repromptText);
        
        return response;
    }

    private JsonObject start(JsonObject session, String userInput) {

        String sessionId = session.getAsJsonPrimitive("sessionId").getAsString();
        JsonObject output = new Start().startSurvey(sessionId, userInput);
        
        String speechText = "";
        
        speechText = output.get("message").getAsString();

        JsonObject response = constructResponseObject(speechText, speechText);
        
        return response;
    }

    private JsonObject reply(JsonObject session, String userOption) {

        String sessionId = session.getAsJsonPrimitive("sessionId").getAsString();
        JsonObject output = new Reply().reply(sessionId, userOption);
        
        String speechText = "", repromptText = "";
        
        speechText = output.get("message").getAsString();
        if(output.has("reprompt"))
        	repromptText = output.get("message").getAsString();

        JsonObject response = constructResponseObject(speechText, repromptText);
        
        return response;
    }
    
    private JsonObject constructResponseObject(String speechText, String repromptText) {
    	JsonObject response = new JsonObject();
    	
    	response.addProperty("version", "1.0");
        
        JsonObject resp = new JsonObject();
        JsonObject outputSpeech = new JsonObject();
        outputSpeech.addProperty("type", "PlainText");
        outputSpeech.addProperty("text", speechText);
        resp.add("outputSpeech", outputSpeech);
        
        JsonObject card = new JsonObject();
        card.addProperty("content", speechText);
        card.addProperty("title", "Session");
        card.addProperty("type", "Simple");
        resp.add("card", card);
        
        JsonObject rePrompt = new JsonObject();
        JsonObject repromptSpeech = new JsonObject();
        repromptSpeech.addProperty("type", "PlainText");
        repromptSpeech.addProperty("text", repromptText);
        rePrompt.add("outputSpeech", repromptSpeech);
        resp.add("reprompt", rePrompt);
        
        resp.addProperty("shouldEndSession", false);
        
        response.add("response", resp);
        response.add("sessionAttributes", new JsonObject());
        
        return response;
    }
}
