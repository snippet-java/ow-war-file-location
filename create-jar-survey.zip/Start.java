import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public class Start {
    
    protected JsonObject startSurvey(String sessionId, String userInput) {

		JsonObject output = new JsonObject();
    	
    	JsonObject book = SurveyService.sessionData.get(sessionId)==null?
				new JsonObject():SurveyService.sessionData.get(sessionId).getAsJsonObject();
		if(!book.has("surveys"))
			output = SurveyService.setRepromptMessage("I cannot find the survey. Please set the survey first. You can say use survey one");
		else {
			
			JsonArray surveys = book.get("surveys").getAsJsonArray();
			int whichChapter = 1;
			JsonObject chapter = surveys.get(whichChapter-1).getAsJsonObject();
			int startPos = 1;
			output = SurveyService.getQASet(chapter, startPos);
			
			book.addProperty("pos", startPos);
			book.addProperty("reading", whichChapter);
			SurveyService.sessionData.add(sessionId, book);
		}
		
    	return output;
    }
}
