import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

public class Use {
	
    protected JsonObject setbook(String sessionId, String userInput) {

		JsonObject output = new JsonObject();
    	
		try { 
			String[] arr = userInput.split("\\s+");
	    	String bookname = "";
	    	for(int i=0; i<arr.length; i++) {
	    		if((i+2)<arr.length) {
	    			//expecting 3rd word to be book name e.g "set book one" 
	    			if((arr[i].equals("use") && arr[i+1].equals("survey"))) {
	    				bookname = arr[i+2];
	    				break;
	    			}
	    		}
	    	}
	    	
	    	if(bookname.isEmpty()) 
	    		output = SurveyService.setRepromptMessage("I am sorry but I do not get the book name. "
	    				+ "You can say use book one.");
	    	else {

	    		JsonObject book = new JsonObject();
	    		//Load the book content
	    		JsonArray surveys = SurveyService.init(bookname);
				
	    		if(surveys == null)
					output = SurveyService.setRepromptMessage("No survey found. Please try again. "
	    					+ "You can say use survey one.");
				else {
					book.add("surveys", surveys);
					book.addProperty("bookName", bookname);
					book.addProperty("bookUrl", SurveyService.library.get(bookname).getAsString());
					SurveyService.sessionData.add(sessionId, book);
		    		
		    		output = SurveyService.setRepromptMessage("Survey successfully loaded");
				}
	    	}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
    	
		return output;
    }
}
