import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class Reply {
    
    protected JsonObject reply(String sessionId, String userOption){
    	
		JsonObject output = new JsonObject();
    	
		JsonObject book = SurveyService.sessionData.get(sessionId)==null?
				null:SurveyService.sessionData.get(sessionId).getAsJsonObject();
		if(book == null)
			output = SurveyService.setRepromptMessage("Please set the survey first. You can say use survey one");
		else {
			if(!book.has("reading"))
				output = SurveyService.setRepromptMessage("Please start the survey first. "
						+ "You can say start survey.");
			else {
				
				JsonArray surveys = book.get("surveys").getAsJsonArray();
				
				int whichChapter = book.get("reading").getAsInt();
				JsonObject survey = surveys.get(whichChapter-1).getAsJsonObject();
				
				if(!book.has("pos")) 
					output = SurveyService.setRepromptMessage("Please start the survey first. "
							+ "You can say start survey.");
				else {
					int currentPos = book.get("pos").getAsInt();
					int nextPos = currentPos;
					
					//Get the next position
					JsonArray materials = survey.get("material").getAsJsonArray();
					JsonObject material = materials.get(currentPos-1).getAsJsonObject();
					
					//when end of node reached or in other words, end of chapter reached
					if(!material.has("options")) {
						String message = "This is the end of survey. ";
						
						if(!message.isEmpty())
							output = SurveyService.setRepromptMessage(message);
					}
					else {
						JsonObject options = material.get("options").getAsJsonObject();
						System.out.println("options: " + options + "\n" + "selected option: " + userOption + "--");
						
						//if user reply with one, two.. match it with the option answer
						int userOptionPos = ConvertWordsToNumber.convert(userOption);
						if(userOptionPos > 0 && userOptionPos <= options.entrySet().size()) {
							List<Entry<String, JsonElement>> optionsList = new ArrayList<Entry<String, JsonElement>>(options.entrySet());
							userOption = optionsList.get(userOptionPos-1).getKey();
						}
						
						if(!options.has(userOption)) {
							//repeat again the question if invalid option given
							output = SurveyService.setRepromptMessage("Invalid option selected. Please try again. " +
									SurveyService.getQASet(survey, currentPos).getAsJsonObject().get("message").getAsString());
						}
						else {
							nextPos = options.get(userOption).getAsInt();
							output = SurveyService.getQASet(survey, nextPos);

						}
					}
					
					//remember the position
					book.addProperty("pos", nextPos);
					SurveyService.sessionData.add(sessionId, book);
				}
			}
		}
		
		return output;
    }
}
