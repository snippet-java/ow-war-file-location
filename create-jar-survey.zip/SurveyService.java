import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map.Entry;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class SurveyService {
	
    protected static JsonObject sessionData = new JsonObject();
    protected static JsonObject library = new JsonObject();
    
    /**
     * Firstly retrieve the location of book (currently from nodered), then load and transform the book content
     * @param urlInput book name input by user
     * @param sessionId user session ID
     * @return book content in json format (elements: message, id, node, options)
     * @throws ClientProtocolException
     * @throws IOException
     */
    protected static JsonArray init(String bookname) throws ClientProtocolException, IOException {
    	fetchBookInfo();
    	
		if(library.has(bookname))
			return transformJsonFromAllFlows(library.get(bookname).getAsString());
		else
			return null;
    }

    protected static JsonArray transformJsonFromAllFlows(String surveyUrl) throws ClientProtocolException, IOException {

		if(!surveyUrl.contains("http"))
			return null;
		
		String result = makeHTTPCall(surveyUrl);
		
		String[] qasets = result.split("\n");
		JsonArray surveys = new JsonArray();
		JsonObject survey = new JsonObject();
		JsonArray outputArray = new JsonArray();
		try {
    		for(int i=0; i<qasets.length; i++) {
    			String qaset = qasets[i];
    			
    			String[] qaArray = qaset.split(";");

    			JsonObject output = new JsonObject(); 
    			if(qaArray.length > 1) {
        			
    				//set the question
        			//assuming first column is always Question
					output.addProperty("message", qaArray[0]);
					
					//set the answers (could be one or more)
//	    			JsonArray answerArray = new JsonArray();
					JsonObject optionJson = new JsonObject();
	    			for(int j=1; j<qaArray.length; j++) {
	    				String option = qaArray[j];
    					//split further if containing (/) character (meant for next action item)
    					if(option.contains("/")) {
    						String[] answerAndAction = option.split("/");
    						optionJson.addProperty(answerAndAction[0].toLowerCase(), Integer.parseInt(answerAndAction[1]));
    					}
    					else {
    						optionJson.addProperty(option.toLowerCase(), i+2);
    					}
	    			}
	    			if(optionJson.entrySet().size() > 0)
	    				output.add("options", optionJson);

    			}
    			//end of survey
    			else 
    				output.addProperty("message", qaArray[0]);

    			outputArray.add(output);
    		}
    		
		} catch(NumberFormatException ex) {
			System.out.println("Error importing survey set. Please check again your answer set. It contains invalid number to point to next question");
			//clear the survey output, to make sure survey file get fixed and complete survey output is delivered
			outputArray = new JsonArray();
		}
		
		System.out.println("Survey generated: \n" + outputArray);
		survey.add("material", outputArray);
		surveys.add(survey);
		
		return surveys;
    }

	/**
	 * Get the question and options
	 * @param chapter
	 * @param position
	 * @return
	 */
    protected static JsonObject getQASet(JsonObject chapter, int position) {
    	JsonObject nextResponse = new JsonObject();
    	
		JsonArray materials = chapter.get("material").getAsJsonArray();
		JsonObject material = materials.get(position-1).getAsJsonObject();

		String responseMessage = "";
		
		responseMessage += material.get("message").getAsString();
		
		if(material.has("options")) {
			JsonObject options = material.get("options").getAsJsonObject();
			int counter = 1;
			for(Entry<String, JsonElement> option : options.entrySet()) {
				responseMessage += ". Option " + counter++ + " " + option.getKey();
			}
		}
		//record into history a chapter has been finished reading
		else {
			nextResponse.addProperty("end", true);
			responseMessage += ". This is the end of Survey. ";
		}

		nextResponse.addProperty("message", responseMessage);
		
		return nextResponse;
    }
    
    protected static JsonObject setRepromptMessage(String message) {
    	JsonObject messageOutput = new JsonObject();
    	
    	messageOutput.addProperty("message", message);
    	messageOutput.addProperty("reprompt", true);
    	messageOutput.add("options", new JsonArray());
    	
    	return messageOutput;
    }
    
    //Match param to books.json. If found, return the matching url. 
    //Otherwise, assume param itself is a valid url
    private static void fetchBookInfo() {
    	
		String result = makeHTTPCall("https://gist.githubusercontent.com/snippet-java/e207ae6bc977b58f99ad5787880db2cd/raw/7463642d896baaea24625ee5d0dc9bb0795d3304/surveys.json");
		
		JsonParser parser = new JsonParser();
		library = parser.parse(result).getAsJsonObject();
		
    }
    
    protected static String makeHTTPCall(String httpURL) {
    	HttpClient client = HttpClientBuilder.create().build();
		HttpGet get = new HttpGet(httpURL);
		HttpResponse resp;
		String result = "";
		try {
			resp = client.execute(get);
			BufferedReader rd = new BufferedReader(
			        new InputStreamReader(resp.getEntity().getContent()));

			String line = "";
			while ((line = rd.readLine()) != null) {
				result += line+"\n";
			}
		} catch (ClientProtocolException e) {
			System.err.println(e.getMessage());
		} catch (IOException e) {
			System.err.println(e.getMessage());
		}
		
		return result;
    }
}
